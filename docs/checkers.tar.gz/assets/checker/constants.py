from pathlib import Path

import pygame

#size of board and square
WIDTH, HEIGHT = 650, 650
ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH//COLS

#Board-er jonn ivory ar forest-green palette.
LIGHT_SQUARE = (238, 232, 213)
DARK_SQUARE = (46, 64, 59)
BACKGROUND = (24, 35, 34)

#RED human player, WHITE AI;
RED = (176, 55, 72)
WHITE = (247, 244, 230)
BLUE = (72, 174, 151)
GREY = (35, 43, 42)

CROWN_PATH = Path(__file__).parent.parent / "assets" / "assets" / "crown.png"
CROWN = pygame.transform.scale(pygame.image.load(str(CROWN_PATH)), (44, 25))
